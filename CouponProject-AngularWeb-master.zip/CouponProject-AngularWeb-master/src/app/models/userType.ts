export enum UserType {
    ADMIN = "ADMIN",
    COMPANY = "COMPANY",
    CUSTOMER = "CUSTOMER",
    GUEST = "GUEST"
}