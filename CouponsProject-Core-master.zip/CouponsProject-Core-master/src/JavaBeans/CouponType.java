package JavaBeans;

public enum CouponType {

	RESTURANTS, ELECTRICITY, FOOD, HEALTH, SPORTS, CAMPING, TRAVELLING
}
