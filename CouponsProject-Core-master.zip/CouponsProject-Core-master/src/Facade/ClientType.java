package Facade;

public enum ClientType {

	ADMIN, COMPANY, CUSTOMER, GUEST;
}
